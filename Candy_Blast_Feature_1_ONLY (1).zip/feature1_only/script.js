const screens = document.querySelectorAll('.screen');
const clickSound = new Audio('assets/click.wav');
function showScreen(id){screens.forEach(screen=>screen.classList.toggle('active',screen.id===id));}
function playClick(){try{clickSound.currentTime=0;clickSound.play().catch(()=>{});}catch(error){}}
document.querySelectorAll('[data-action]').forEach(button=>button.addEventListener('click',()=>{
  playClick();
  const action=button.dataset.action;
  if(action==='play') showScreen('difficulty');
  else if(action==='instructions') showScreen('instructions');
  else if(action==='exit') showScreen('exit');
  else if(action==='menu') showScreen('menu');
}));
document.querySelectorAll('.easy,.medium,.hard').forEach(button=>button.addEventListener('click',()=>{
  playClick();
  alert(button.textContent+' mode selected. Difficulty selection is part of the Start Menu navigation demo.');
}));
