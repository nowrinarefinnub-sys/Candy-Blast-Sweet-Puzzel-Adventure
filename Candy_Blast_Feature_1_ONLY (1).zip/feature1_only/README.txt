CANDY BLAST – FEATURE 1 ONLY
Feature: Start Menu

This is a separate, small demonstration project for Feature 1 only.
It includes the main menu, Play / Instructions / Exit buttons, screen navigation,
back-to-menu navigation, candy decorations, hover effects and click sound.
It does NOT include the full match-3 gameplay, candy grid, scoring or level gameplay.

HOW TO RUN:
1. Extract this ZIP file.
2. Open the feature1_only folder in VS Code.
3. Open index.html with Live Server (or open it in a browser).
4. Test PLAY, INSTRUCTIONS, EXIT and BACK TO MENU.

Files:
- index.html: screen structure
- style.css: design, buttons, animation and responsive layout
- script.js: button click and screen navigation logic
- assets/: original Candy Blast image and click-sound assets
